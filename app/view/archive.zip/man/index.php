<?php $i = 1; ?>
            <?php foreach( $data['pdk'] as $pdk) : ?>
            <div class="rec22" >
                <?= $pdk["nama"]; ?>
                <img class="tenda" src="<?= $pdk["image"]; ?>" alt="">
                <div class="diskripsi">
                    <div class="harga">
                        Rp<?= $pdk["harga"]; ?>
                    </div>
                    <?= $pdk["deskripsi"]; ?>
                </div>
                   
            </div>
            <?php $i++; ?>
            <?php endforeach; ?>

