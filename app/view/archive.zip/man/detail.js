const openButton = document.getElementById('openPopup');
const popup = document.getElementById('popup');
const closeButton = document.getElementById('closePopup');

openButton.addEventListener('click', function() {
  popup.style.display = 'flex';
});

closeButton.addEventListener('click', function() {
  popup.style.display = 'none';
});

// Tutup pop-up jika pengguna mengklik di luar area pop-up
window.addEventListener('click', function(event) {
  if (event.target === popup) {
    popup.style.display = 'none';
  }
});

function openPopup() {
  const popup = document.getElementById('popup');
  popup.style.display = 'flex';
}