<body>
   <div class="aboutisi">
        <div class="aboutisi3">
            <div>
                <img src="<?= $data['pdk']['gambar_produk']; ?>" alt="">
                <h5><?= $data['pdk']['nama_produk']; ?></h5>
            </div>
            <div class="fontabo">
                <h5><?= $data['pdk']['deskripsi_pdk']; ?></h5>
                <button class="openPopup" data-popup="beli" data-order = "">Beli</button>
                <button class="openPopup" data-popup="sewa">Sewa</button>
<!-- ===================logika======================= -->
                <div class="popup" id="popup">
                <div class="popup-content" id="popupBeli">
                    <span class="close" id="closePopup">&times;</span>
                    <h2>Detail Pembelian</h2>
                    <p>Silakan mengisi sesuai dengan kebutuhan</p>
                   
                    <div class="inputform">
                        <form action= "<?= BASEURL ?>/index.php?url=Pembayaran/tambah" method="post">
                        <!-- ====================tabel detail produk================= -->
                        <div>
                            <label for="jumlah_produk">Jumlah</label>
                            <input type="number" id="jumlah_produk" name="jumlah_produk">
                        </div><br>
                        <label>
                            <input type="radio" name="ukuran_produk" value="M" />
                            <span class="custom-radio"></span>
                            SIZE M
                        </label>
                        <label>
                            <input type="radio" name="ukuran_produk" value="L" />
                            <span class="custom-radio"></span>
                            SIZE L
                        </label>
                        <label>
                            <input type="radio" name="ukuran_produk" value="XL" />
                            <span class="custom-radio"></span>
                            SIZE XL
                        </label><br><br>
                       
                        
                       
                        <button type="submit">Beli</button>

                        <!-- ====================tabel detail produk================= -->
                    </form>   
                    </div>
                </div>

                <div class="popup-content" id="popupSewa">
                    <span class="close" id="closePopup">&times;</span>
                    <h2>Detail Penyewaan</h2>
                    <p>Silakan mengisi sesuai dengan kebutuhan</p>
                    <div class="inputform">
                        <form action= "">
                        <div>
                            <label for="">Jumlah</label>
                            <input type="number"/>
                        </div>
                        <div>
                            <label for="">Ukuran</label>
                            <input type="text"/>
                        </div>
                        <div>
                            <label for="">Lama Peminjaman</label>
                            <input type="text"/>
                        </div>
                        <button>Sewa</button>
                        </form>   
                    </div>
                </div>
                </div>

            </div>
        </div>
   </div>
</body>